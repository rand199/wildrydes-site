window._config = {
    cognito: {
        userPoolId:         'us-west-2_rqsdRyhGu',         // e.g. us-west-2_rqsdRyhGu
        userPoolClientId:   '5dvl727n4qmbcttc6sv2jbt6v7',         // e.g. 5dvl727n4qmbcttc6sv2jbt6v7
        region:             'us-west-2'          // e.g. us-east-2
    },
    api: {
        invokeUrl:          'https://ixcpfwo80g.execute-api.us-west-2.amazonaws.com/prod'          // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod',
    }
};
